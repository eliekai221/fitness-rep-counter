# Universal Rep Counter (Flutter template)

This repo is preconfigured to **build an Android APK automatically** on GitHub.

## How it works
- Minimal Flutter app in `lib/main.dart`.
- GitHub Actions workflow runs:
  1) `flutter create . --platforms=android,web` to generate `android/` etc.
  2) `flutter pub get`
  3) `flutter build apk --release`
  4) Uploads the APK as an artifact.

## How to use
1. Upload these files to your GitHub repo (root):
   - `lib/main.dart`
   - `pubspec.yaml`
   - `.github/workflows/build.yml`
   - `README.md`
2. Commit to `main`.
3. Go to the **Actions** tab → open the last run → download the APK artifact.

You can later replace `lib/main.dart` with your real app (camera, pose, etc.).
